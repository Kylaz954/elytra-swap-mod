
package com.elytraswap;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ElytraItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.ActionResult;

public class ElytraSwapMod implements ModInitializer {

    @Override
    public void onInitialize() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.isClient) {
                ItemStack usedItem = player.getStackInHand(hand);
                ItemStack chestSlot = player.getEquippedStack(EquipmentSlot.CHEST);

                // Swap if either item is Elytra or Chestplate
                if (isSwappable(usedItem) && isSwappable(chestSlot)) {
                    player.equipStack(EquipmentSlot.CHEST, usedItem.copy());
                    player.setStackInHand(hand, chestSlot.copy());
                    return TypedActionResult.success(usedItem, world.isClient());
                }
            }
            return TypedActionResult.pass(ItemStack.EMPTY);
        });
    }

    private boolean isSwappable(ItemStack stack) {
        return stack.getItem() instanceof ElytraItem || stack.getItem() instanceof ArmorItem;
    }
}
